﻿# Changelog

## [1.0.0] - Initial
- Add test plan/strategy
- Add login & registration test cases
- Add sample bug report
- Add Postman collection and API test report
- Add SQL verification samples
- Add SDLC/STLC diagrams
